package com.example;

import com.example.grpc.AppProto.*;
import com.example.grpc.AppServiceGrpc;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.UnknownHostException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class AppClient {

    private final AppServiceGrpc.AppServiceBlockingStub blockingStub;
    private final AppServiceGrpc.AppServiceStub asyncStub;  // Para streaming
    private final String subscriberName;

    public AppClient(String localHost, int localPort, String serverHost, int serverPort) throws UnknownHostException {
        SocketAddress localSocket = new InetSocketAddress(localHost, localPort);

        ManagedChannel channel = ManagedChannelBuilder.forAddress(serverHost, serverPort)
                .usePlaintext()
                .build();

        blockingStub = AppServiceGrpc.newBlockingStub(channel);
        asyncStub = AppServiceGrpc.newStub(channel);  // Para streaming
        subscriberName = localHost + ":" + localPort;  // Identifica o cliente pelo IP e porta locais
    }

    public void startClient() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\nAvailable commands:\n");
        System.out.println("1. create [channel_name] [channel_type]");
        System.out.println("2. subscribe [channel_name]");
        System.out.println("3. publish [channel_name] [message]");
        System.out.println("4. listReceived [channel_name]");
        System.out.println("5. listSent [channel_name]");
        System.out.println("6. receive [channel_name]");
        System.out.println("7. remove [channel_name]");
        System.out.println("8. unsubscribe [channel_name]");
        System.out.println("9. listChannels");
        System.out.println("10. stream [channel_name] [duration_seconds]");
        System.out.println("11. exit\n");

        while (true) {
            System.out.print("\nEnter command: \n");
            String input;

            try {
                input = scanner.nextLine().trim();
            } catch (NoSuchElementException | IllegalStateException e) {
                System.out.println("\nError reading input. Exiting...\n");
                break;
            }

            if (input.isEmpty()) {
                continue;
            }

            String[] args = input.split(" ");

            if (args[0].equalsIgnoreCase("exit")) {
                System.out.println("\nExiting...\n");
                break;
            }

            switch (args[0].toLowerCase()) {
                case "create":
                    if (args.length == 3) {
                        createChannel(args[1], args[2]);
                    } else {
                        System.out.println("\nInvalid command. Usage: create [channel_name] [channel_type]\n");
                    }
                    break;
                case "subscribe":
                    if (args.length == 2) {
                        createSubscription(args[1]);
                    } else {
                        System.out.println("\nInvalid command. Usage: subscribe [channel_name]\n");
                    }
                    break;
                case "publish":
                    if (args.length >= 3) {
                        publishMessage(args[1], input.substring(input.indexOf(args[2])));
                    } else {
                        System.out.println("\nInvalid command. Usage: publish [channel_name] [message]\n");
                    }
                    break;
                case "listreceived":
                    if (args.length == 2) {
                        listReceived(args[1]);
                    } else {
                        System.out.println("\nInvalid command. Usage: listReceived [channel_name]\n");
                    }
                    break;
                case "listsent":
                    if (args.length == 2) {
                        listSent(args[1]);
                    } else {
                        System.out.println("\nInvalid command. Usage: listSent [channel_name]\n");
                    }
                    break;
                case "receive":
                    if (args.length == 2) {
                        receivedMessage(args[1]);
                    } else {
                        System.out.println("\nInvalid command. Usage: receive [channel_name]\n");
                    }
                    break;
                case "remove":
                    if (args.length == 2) {
                        removeChannel(args[1]);
                    } else {
                        System.out.println("\nInvalid command. Usage: remove [channel_name]\n");
                    }
                    break;
                case "unsubscribe":
                    if (args.length == 2) {
                        unsubscribe(args[1]);
                    } else {
                        System.out.println("\nInvalid command. Usage: unsubscribe [channel_name]\n");
                    }
                    break;
                case "listchannels":
                    listChannels();
                    break;
                case "stream":
                    if (args.length == 3) {
                        streamMessages(args[1], Integer.parseInt(args[2]));
                    } else {
                        System.out.println("\nInvalid command. Usage: stream [channel_name] [duration_seconds]\n");
                    }
                    break;
                default:
                    System.out.println("\nUnknown command. Please try again.\n");
                    break;
            }
        }
        scanner.close();
    }

    public void createChannel(String channelName, String channelType) {
        CreateChannelRequest request = CreateChannelRequest.newBuilder()
                .setChannelName(channelName)
                .setChannelType(channelType)
                .setCreator(subscriberName)  // Usa o IP e porta locais do cliente
                .build();
        GenericResponse response = blockingStub.createChannel(request);
        System.out.println("\nResponse: " + response.getMessage() + "\n");
    }

    public void createSubscription(String channelName) {
        CreateSubscriptionRequest request = CreateSubscriptionRequest.newBuilder()
                .setChannelName(channelName)
                .setSubscriber(subscriberName)  // Usa o IP e porta locais do cliente
                .build();
        GenericResponse response = blockingStub.createSubscription(request);
        System.out.println("\nResponse: " + response.getMessage() + "\n");
    }

    public void publishMessage(String channelName, String content) {
        PublishRequest request = PublishRequest.newBuilder()
                .setChannelName(channelName)
                .setSubscriberName(subscriberName)  // Usa o IP e porta locais do cliente
                .setTextContent(content)
                .build();
        GenericResponse response = blockingStub.publish(request);
        System.out.println("\nResponse: " + response.getMessage() + "\n");
    }

    public void listReceived(String channelName) {
        ListRequest request = ListRequest.newBuilder()
                .setChannelName(channelName)
                .setSubscriberName(subscriberName)  // Usa o IP e porta locais do cliente
                .build();
        ListResponse response = blockingStub.listReceived(request);
        System.out.println("\nMessages received: " + response.getCount() + "\n");
    }

    public void listSent(String channelName) {
        ListRequest request = ListRequest.newBuilder()
                .setChannelName(channelName)
                .setSubscriberName(subscriberName)  // Usa o IP e porta locais do cliente
                .build();
        ListResponse response = blockingStub.listSent(request);
        System.out.println("\nMessages sent: " + response.getCount() + "\n");
    }

    public void receivedMessage(String channelName) {
        ReceivedRequest request = ReceivedRequest.newBuilder()
                .setChannelName(channelName)
                .setSubscriberName(subscriberName)  // Usa o IP e porta locais do cliente
                .build();
        ReceivedResponse response = blockingStub.received(request);
        System.out.println("\nReceived message: " + response.getTextContent() + "\n");
    }

    public void removeChannel(String channelName) {
        RemoveChannelRequest request = RemoveChannelRequest.newBuilder()
                .setChannelName(channelName)
                .setSubscriberName(subscriberName)  // Usa o IP e porta locais do cliente
                .build();
        GenericResponse response = blockingStub.removeChannel(request);
        System.out.println("\nResponse: " + response.getMessage() + "\n");
    }

    public void unsubscribe(String channelName) {
        UnsubscribeRequest request = UnsubscribeRequest.newBuilder()
                .setChannelName(channelName)
                .setSubscriberName(subscriberName)  // Usa o IP e porta locais do cliente
                .build();
        GenericResponse response = blockingStub.unsubscribe(request);
        System.out.println("\nResponse: " + response.getMessage() + "\n");
    }

    public void listChannels() {
        EmptyRequest request = EmptyRequest.newBuilder().build();
        ListChannelsResponse response = blockingStub.listChannels(request);
        response.getChannelsList().forEach(channel -> System.out.println("\n" + channel.getChannelName() + "\n"));
    }

    public void streamMessages(String channelName, int durationSeconds) {
        StreamRequest request = StreamRequest.newBuilder()
                .setChannelName(channelName)
                .setSubscriberName(subscriberName)
                .setDurationSeconds(durationSeconds)
                .build();

        asyncStub.stream(request, new StreamObserver<StreamResponse>() {
            @Override
            public void onNext(StreamResponse value) {
                System.out.println("\nReceived streamed message: " + value.getTextContent() + "\n");
            }

            @Override
            public void onError(Throwable t) {
                System.err.println("\nStream error: " + t.getMessage() + "\n");
            }

            @Override
            public void onCompleted() {
                System.out.println("\nStream completed\n");
            }
        });
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter local host: \n");
        String localHost = scanner.nextLine().trim();

        System.out.print("Enter local port: \n");
        int localPort = Integer.parseInt(scanner.nextLine().trim());

        String serverHost = "localhost";  // Host do servidor fixo
        int serverPort = 50052;  // Porta do servidor fixo

        try {
            AppClient client = new AppClient(localHost, localPort, serverHost, serverPort);
            client.startClient();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }
}
