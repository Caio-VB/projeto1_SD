package com.example;

import com.example.grpc.AppProto;
import com.example.grpc.AppServiceGrpc;
import io.grpc.stub.StreamObserver;

import java.io.*;
import java.util.*;

public class AppServiceImpl extends AppServiceGrpc.AppServiceImplBase {

    // Mapeamento dos canais no servidor
    private Map<String, Channel> channels = new HashMap<>();

    // Caminho relativo dentro do diretório do projeto
    private static final String FILE_PATH = "data/channels_and_subscriptions.dat";

    public AppServiceImpl() {
        loadData();
    }

    // Implementações dos métodos gRPC

    @Override
    public void createChannel(AppProto.CreateChannelRequest req, StreamObserver<AppProto.GenericResponse> responseObserver) {
        String channelName = req.getChannelName();
        String channelType = req.getChannelType();
        String creator = req.getCreator();

        if (channels.containsKey(channelName)) {
            AppProto.GenericResponse response = AppProto.GenericResponse.newBuilder()
                .setMessage("Channel with this name already exists.")
                .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
            return;
        }

        Channel channel = new Channel(channelName, channelType, creator);
        channel.addSubscription(new Subscription(creator));
        channels.put(channelName, channel);
        saveData();

        AppProto.GenericResponse response = AppProto.GenericResponse.newBuilder()
            .setMessage("Channel created successfully.")
            .build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void createSubscription(AppProto.CreateSubscriptionRequest req, StreamObserver<AppProto.GenericResponse> responseObserver) {
        String channelName = req.getChannelName();
        String subscriber = req.getSubscriber();

        Channel channel = channels.get(channelName);

        if (channel == null) {
            AppProto.GenericResponse response = AppProto.GenericResponse.newBuilder()
                .setMessage("Channel does not exist.")
                .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
            return;
        }

        if (channel.getSubscription(subscriber) != null) {
            AppProto.GenericResponse response = AppProto.GenericResponse.newBuilder()
                .setMessage("Subscriber is already subscribed to this channel.")
                .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
            return;
        }

        channel.addSubscription(new Subscription(subscriber));
        saveData();

        AppProto.GenericResponse response = AppProto.GenericResponse.newBuilder()
            .setMessage(subscriber + " has subscribed to " + channelName + " channel.")
            .build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void publish(AppProto.PublishRequest req, StreamObserver<AppProto.GenericResponse> responseObserver) {
        String channelName = req.getChannelName();
        String subscriberName = req.getSubscriberName();

        Channel channel = channels.get(channelName);

        if (channel == null) {
            AppProto.GenericResponse response = AppProto.GenericResponse.newBuilder()
                .setMessage("Channel not found.")
                .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
            return;
        }

        Subscription subscription = channel.getSubscription(subscriberName);

        if (subscription == null) {
            AppProto.GenericResponse response = AppProto.GenericResponse.newBuilder()
                .setMessage("Subscription not found.")
                .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
            return;
        }

        String messageId = UUID.randomUUID().toString();
        Message message;
        if (req.hasTextContent()) {
            message = new Message(messageId, req.getTextContent());
        } else {
            message = new Message(messageId, req.getBinaryContent().toByteArray());
        }

        if (channel.getType().equals("multiple")) {
            channel.getSubscriptions().stream()
                .filter(s -> !s.getSubscriber().equals(subscriberName))
                .forEach(s -> s.receiveMessage(message));
        } else if (channel.getType().equals("simple")) {
            List<Subscription> otherSubscribers = new ArrayList<>();
            for (Subscription s : channel.getSubscriptions()) {
                if (!s.getSubscriber().equals(subscriberName)) {
                    otherSubscribers.add(s);
                }
            }

            if (!otherSubscribers.isEmpty()) {
                Random random = new Random();
                Subscription randomSubscriber = otherSubscribers.get(random.nextInt(otherSubscribers.size()));
                randomSubscriber.receiveMessage(message);
            }
        }

        subscription.sendMessage(message);
        saveData();

        AppProto.GenericResponse response = AppProto.GenericResponse.newBuilder()
            .setMessage("Message published successfully.")
            .build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void received(AppProto.ReceivedRequest req, StreamObserver<AppProto.ReceivedResponse> responseObserver) {
        String channelName = req.getChannelName();
        String subscriberName = req.getSubscriberName();

        Channel channel = channels.get(channelName);

        if (channel == null) {
            responseObserver.onError(new Throwable("Channel not found."));
            return;
        }

        Subscription subscription = channel.getSubscription(subscriberName);

        if (subscription == null || subscription.getMessagesReceived().isEmpty()) {
            responseObserver.onError(new Throwable("Subscription not found or no messages received."));
            return;
        }

        Message oldestMessage = subscription.getMessagesReceived().get(0);
        subscription.getMessagesReceived().remove(0);

        boolean messageStillExists = channel.getSubscriptions().stream()
            .anyMatch(s -> s.getMessagesReceived().stream().anyMatch(m -> m.getId().equals(oldestMessage.getId())));

        if (!messageStillExists) {
            channel.getSubscriptions().forEach(s -> s.getMessagesSent().removeIf(m -> m.getId().equals(oldestMessage.getId())));
        }

        saveData();

        AppProto.ReceivedResponse.Builder responseBuilder = AppProto.ReceivedResponse.newBuilder()
            .setMessageId(oldestMessage.getId());

        if (oldestMessage.getType() == MessageType.TEXT) {
            responseBuilder.setTextContent(oldestMessage.getContent());
        } else {
            responseBuilder.setBinaryContent(com.google.protobuf.ByteString.copyFrom(oldestMessage.getData()));
        }

        responseObserver.onNext(responseBuilder.build());
        responseObserver.onCompleted();
    }

    @Override
    public void stream(AppProto.StreamRequest req, StreamObserver<AppProto.StreamResponse> responseObserver) {
        String channelName = req.getChannelName();
        String subscriberName = req.getSubscriberName();
        int durationSeconds = req.getDurationSeconds();

        Channel channel = channels.get(channelName);

        if (channel == null) {
            responseObserver.onError(new Throwable("Channel not found."));
            return;
        }

        Subscription subscription = channel.getSubscription(subscriberName);

        if (subscription == null) {
            responseObserver.onError(new Throwable("Subscription not found."));
            return;
        }

        long endTime = System.currentTimeMillis() + durationSeconds * 1000L;

        try {
            while (System.currentTimeMillis() < endTime) {
                synchronized (subscription) {
                    if (!subscription.getMessagesReceived().isEmpty()) {
                        Message message = subscription.getMessagesReceived().remove(0); // Remove a mensagem da lista

                        AppProto.StreamResponse.Builder responseBuilder = AppProto.StreamResponse.newBuilder()
                                .setMessageId(message.getId());

                        if (message.getType() == MessageType.TEXT) {
                            responseBuilder.setTextContent(message.getContent());
                        } else {
                            responseBuilder.setBinaryContent(com.google.protobuf.ByteString.copyFrom(message.getData()));
                        }

                        responseObserver.onNext(responseBuilder.build());

                        // Verificar se a mensagem ainda existe em outras subscriptions
                        boolean messageStillExists = channel.getSubscriptions().stream()
                                .anyMatch(s -> s.getMessagesReceived().stream().anyMatch(m -> m.getId().equals(message.getId())));

                        // Se a mensagem não existir em nenhuma outra subscription, removê-la da lista de mensagens enviadas
                        if (!messageStillExists) {
                            channel.getSubscriptions().forEach(s -> s.getMessagesSent().removeIf(m -> m.getId().equals(message.getId())));
                        }
                    }
                }

                Thread.sleep(100); // Pequeno intervalo para evitar loop contínuo sem pausa
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            responseObserver.onError(e);
        } finally {
            responseObserver.onCompleted();
        }
    }

    @Override
    public void listSent(AppProto.ListRequest req, StreamObserver<AppProto.ListResponse> responseObserver) {
        String channelName = req.getChannelName();
        String subscriberName = req.getSubscriberName();

        Channel channel = channels.get(channelName);

        if (channel == null) {
            responseObserver.onError(new Throwable("Channel not found."));
            return;
        }

        Subscription subscription = channel.getSubscription(subscriberName);

        if (subscription == null) {
            responseObserver.onError(new Throwable("Subscription not found."));
            return;
        }

        AppProto.ListResponse response = AppProto.ListResponse.newBuilder()
            .setCount(subscription.getMessagesSent().size())
            .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void removeChannel(AppProto.RemoveChannelRequest req, StreamObserver<AppProto.GenericResponse> responseObserver) {
        String channelName = req.getChannelName();
        String subscriberName = req.getSubscriberName();

        Channel channel = channels.get(channelName);

        if (channel == null) {
            AppProto.GenericResponse response = AppProto.GenericResponse.newBuilder()
                .setMessage("Channel not found.")
                .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
            return;
        }

        if (!channel.getCreator().equals(subscriberName)) {
            AppProto.GenericResponse response = AppProto.GenericResponse.newBuilder()
                .setMessage("Only the creator can remove this channel.")
                .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
            return;
        }

        channels.remove(channelName);
        saveData();

        AppProto.GenericResponse response = AppProto.GenericResponse.newBuilder()
            .setMessage("Channel removed successfully.")
            .build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void unsubscribe(AppProto.UnsubscribeRequest req, StreamObserver<AppProto.GenericResponse> responseObserver) {
        String channelName = req.getChannelName();
        String subscriberName = req.getSubscriberName();

        Channel channel = channels.get(channelName);

        if (channel == null) {
            AppProto.GenericResponse response = AppProto.GenericResponse.newBuilder()
                .setMessage("Channel not found.")
                .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
            return;
        }

        Subscription subscription = channel.getSubscription(subscriberName);

        if (subscription == null) {
            AppProto.GenericResponse response = AppProto.GenericResponse.newBuilder()
                .setMessage("Subscription not found.")
                .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
            return;
        }

        channel.removeSubscription(subscriberName);
        saveData();

        AppProto.GenericResponse response = AppProto.GenericResponse.newBuilder()
            .setMessage(subscriberName + " has unsubscribed from " + channelName + " channel.")
            .build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void listChannels(AppProto.EmptyRequest req, StreamObserver<AppProto.ListChannelsResponse> responseObserver) {
        AppProto.ListChannelsResponse.Builder responseBuilder = AppProto.ListChannelsResponse.newBuilder();

        for (Channel channel : channels.values()) {
            AppProto.ChannelInfo channelInfo = AppProto.ChannelInfo.newBuilder()
                .setChannelName(channel.getName())
                .setChannelType(channel.getType())
                .setCreator(channel.getCreator())
                .setSubscriberCount(channel.getSubscriptions().size())
                .build();
            responseBuilder.addChannels(channelInfo);
        }

        responseObserver.onNext(responseBuilder.build());
        responseObserver.onCompleted();
    }

    // Métodos de persistência

    private void saveData() {
        try {
            // Certificar que o diretório existe, se não, criar o diretório
            File file = new File(FILE_PATH);
            file.getParentFile().mkdirs();

            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                oos.writeObject(channels);
                System.out.println("Data saved successfully.");
            }
        } catch (IOException e) {
            System.err.println("Failed to save data: " + e.getMessage());
        }
    }

    private void loadData() {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            channels = new HashMap<>();
            System.out.println("No data file found, starting with an empty dataset.");
            return;
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            channels = (Map<String, Channel>) ois.readObject();
            System.out.println("Data loaded successfully.");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Failed to load data: " + e.getMessage());
        }
    }

    // Classe interna Message
    class Message implements Serializable {
        private static final long serialVersionUID = 1L;
        private final String id;
        private final String content; // Usado para mensagens de texto
        private final byte[] data;    // Usado para mensagens binárias
        private final MessageType type;

        public Message(String id, Object content) {
            this.id = id;

            if (content instanceof String) {
                this.content = (String) content;
                this.data = null;
                this.type = MessageType.TEXT;
            } else if (content instanceof byte[]) {
                this.content = null;
                this.data = (byte[]) content;
                this.type = MessageType.BINARY;
            } else {
                throw new IllegalArgumentException("Unsupported message type");
            }
        }

        public String getId() {
            return id;
        }

        public String getContent() {
            return content;
        }

        public byte[] getData() {
            return data;
        }

        public MessageType getType() {
            return type;
        }
    }

    // Enum MessageType
    enum MessageType {
        TEXT,
        BINARY
    }

    // Classe interna Subscription
    class Subscription implements Serializable {
        private static final long serialVersionUID = 1L;
        private String subscriber;
        private List<Message> messagesReceived;
        private List<Message> messagesSent;

        public Subscription(String subscriber) {
            this.subscriber = subscriber;
            this.messagesReceived = new ArrayList<>();
            this.messagesSent = new ArrayList<>();
        }

        public String getSubscriber() {
            return subscriber;
        }

        public List<Message> getMessagesReceived() {
            return messagesReceived;
        }

        public List<Message> getMessagesSent() {
            return messagesSent;
        }

        public void receiveMessage(Message message) {
            this.messagesReceived.add(message);
        }

        public void sendMessage(Message message) {
            this.messagesSent.add(message);
        }
    }

    // Classe interna Channel
    class Channel implements Serializable {
        private static final long serialVersionUID = 1L;
        private String name;
        private String type; // "simple" ou "multiple"
        private String creator;
        private List<Subscription> subscriptions;

        public Channel(String name, String type, String creator) {
            this.name = name;
            this.type = type;
            this.creator = creator;
            this.subscriptions = new ArrayList<>();
        }

        public String getName() {
            return name;
        }

        public String getType() {
            return type;
        }

        public String getCreator() {
            return creator;
        }

        public List<Subscription> getSubscriptions() {
            return subscriptions;
        }

        public Subscription getSubscription(String subscriber) {
            return subscriptions.stream()
                .filter(s -> s.getSubscriber().equals(subscriber))
                .findFirst()
                .orElse(null);
        }

        public void addSubscription(Subscription subscription) {
            subscriptions.add(subscription);
        }

        public void removeSubscription(String subscriber) {
            subscriptions.removeIf(s -> s.getSubscriber().equals(subscriber));
        }
    }
}
